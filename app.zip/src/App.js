import ManifestationDashboard from './components/ManifestationDashboard';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ManifestationDashboard />
    </div>
  );
}

export default App;